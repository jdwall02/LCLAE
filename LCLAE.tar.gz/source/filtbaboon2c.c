/* filtbaboon2c.c - Takes a _genolik file and calculates the probability of
the data as a function of the ancestry configuration.  Usage:

filtbaboon2c n pop1 pop2 test

n = sample size (each row of the input file should have 3n+1 entries)
pop1 = individuals belonging to reference population 1
pop2 = individuals belonging to reference population 2
test = test individual

All individuals are numbered sequentially from 1 to n.  pop1 and pop2 take
the following format: the number of individuals in the reference group, 
followed by the individual numbers within the group.

Output:

For each SNP, the output consists of

pos delta L0 L1 L2

pos = base position
delta = difference in estimated allele frequency in the 2 reference groups
Lx = probability of the data (averaged over genotypes) given an ancestry
configuration with x alleles from pop1.

For questions, contact Jeff Wall <jeff.wall@ucsf.edu>
April 5, 2016
*/

#include <stdio.h>
#include <stdlib.h>

int main (int argc, char *argv[])
{
  int a, b, test1, n, pos, flag, *Pop1, *Pop2, c;
  double L1, L2, L3, f1, f2, **lik, deltaf;
  FILE *pop1, *pop2;

  if (argc != 5) {
    printf("Usage: filtbaboon2c n pop1 pop2 test1\n");
    exit(0);
  }

  n = atoi (argv[1]);
  test1 = atoi (argv[4]);

  Pop1 = (int *) malloc (n * sizeof (int));
  Pop2 = (int *) malloc (n * sizeof (int));
  for (a=0; a<n; ++a) {
    Pop1[a] = 0;
    Pop2[a] = 0;
  }
  lik = (double **) malloc ((n+1) * sizeof (double *));
  for (a=1; a<=n; ++a)
    lik[a] = (double *) malloc (3 * sizeof (double *));
  pop1 = fopen (argv[2], "r");
  fscanf (pop1, "%d ", &b);
  for (a=0; a<b; ++a) {
    fscanf (pop1, "%d ", &c);
    Pop1[c] = 1;
  }
  fclose (pop1);

  pop2 = fopen (argv[3], "r");
  fscanf (pop2, "%d ", &b);
  for (a=0; a<b; ++a) {
    fscanf (pop2, "%d ", &c);
    Pop2[c] = 1;
  }
  fclose (pop2);

  while (scanf ("%*s %d ", &pos) != EOF) {
    flag = 0;
    for (a=1; a<=n; ++a)
      scanf ("%lf %lf %lf ", &lik[a][0], &lik[a][1], &lik[a][2]);

    if (lik[test1][0] < -.1)
      flag = 1;

    f1 = f2 = 0.;
    L1 = L2 = L3 = 0.;
    for (a=1; a<=n; ++a)
      if (Pop1[a]>0) {
	if (lik[a][0] > -.1)
	  L1 += lik[a][0];
	if (lik[a][1] > -.1)
	  L2 += lik[a][1];
	if (lik[a][2] > -.1)
	  L3 += lik[a][2];
      }
    if ((L1+L2+L3)>0.)
      f1 = (L1+.5*L2) / (L1+L2+L3);
    else 
      flag = 1;
    
    L1 = L2 = L3 = 0.;
    for (a=1; a<=n; ++a)
      if (Pop2[a]>0) {
	if (lik[a][0] > -.1)
	  L1 += lik[a][0];
	if (lik[a][1] > -.1)
	  L2 += lik[a][1];
	if (lik[a][2] > -.1)
	  L3 += lik[a][2];
      }
    if ((L1+L2+L3)>0.)
      f2 = (L1+.5*L2) / (L1+L2+L3);
    else
      flag = 1;

    if (flag==0) {
      deltaf = (f1 > f2) ? (f1-f2) : (f2-f1) ;

      L1 = lik[test1][0]*f1*f1 + lik[test1][1]*2.*f1*(1.-f1) +
	lik[test1][2]*(1.-f1)*(1.-f1);
      L2 = lik[test1][0]*f1*f2 + lik[test1][1]*(f1*(1.-f2) + f2*(1.-f1)) +
	lik[test1][2]*(1.-f1)*(1.-f2);
      L3 = lik[test1][0]*f2*f2 + lik[test1][1]*2.*f2*(1.-f2) +
	lik[test1][2]*(1.-f2)*(1.-f2);
      
      printf("%d\t%lf\t%lf\t%lf\t%lf\n", pos, deltaf, L1, L2, L3);
    }
  }
}

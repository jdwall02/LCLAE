/* filtbaboon1b.c - Takes filtered vcf files (e.g., in1)
and converts them into a list of genotype likelihood (PL) files.  

Output format: Each line is a SNP, consisting of the base position 
followed by the 3 genotype likelihoods (or -1. for missing data) for each 
of n different individuals.  n=47 for the example data.
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main (int argc, char *argv[])
{
  int a, n, pos, g1, g2, g3, cov;
  double l1, l2, l3;
  char sname[20];

  if (argc != 2) {
    printf("Usage: filtbaboon1b n\n");
    exit(0);
  }
  n = atoi (argv[1]);

  while (scanf ("%s %d ", &sname, &pos) != EOF) {
    printf("%s %d ", sname, pos);
    for (a=0; a<n; ++a) {
      scanf ("%d\n", &cov);
      if (cov == 999) {
	scanf ("%*s %*s %*s %*s %*s");
	printf ("-1. -1. -1. ");
      }
      else {
	scanf ("%*s %*s %*s %*s %d,%d,%d ", &g1, &g2, &g3);
	l1 = pow (10., -g1/10.);
	l2 = pow (10., -g2/10.);
	l3 = pow (10., -g3/10.);
	printf ("%lf %lf %lf ", l1/(l1+l2+l3), l2/(l1+l2+l3), l3/(l1+l2+l3));
      }
    }
    printf("\n");
  }
}

/* geno_lik.c - Takes output from filtbaboon2c and calculates the log-
likelihood of each ancestral configuration.  SNPs with delta < d are thrown 
out.  SNPs with a probability of 0 for any ancestral configuration are 
thrown out as well.

*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main (int argc, char *argv[])
{
  int a;
  double pos, lik_2_0, lik_1_1, lik_0_2, p0, p1, p2, d, delta;

  if (argc != 2) {
    printf("Usage: geno_lik d\n");
    exit(0);
  }

  d = atof (argv[1]);
  lik_2_0 = lik_1_1 = lik_0_2 = 0.;

  while (scanf("%lf %lf %lf %lf %lf\n", &pos, &delta, &p2, &p1, &p0) != EOF) {
    if ((delta > (d - 1.E-08)) && p0>1.E-06 && p1>1.E-06 && p2>1.E-06) {
      lik_2_0 += log (p2);
      lik_1_1 += log (p1);
      lik_0_2 += log (p0);
    }
  }
  if (lik_2_0>lik_1_1 && lik_2_0>lik_0_2)
    printf("2\n");
  else if (lik_0_2>lik_1_1 && lik_2_0<lik_0_2)
    printf("0\n");
  else
    printf("1\n");
}
      

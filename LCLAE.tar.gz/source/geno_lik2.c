/* geno_lik2.c - Takes output from filtbaboon2c and calculates the log-
likelihood of each ancestral configuration for sliding windows of length t.  
SNPs with delta < d are thrown out.  SNPs with a probability of 0 for any 
ancestral configuration are thrown out.  Then, for each SNP, we tabulate the 
most likely configuration for each window containing it, and use 
majority-rule to generate an ancestry call.  Output for each SNP is the 
number of alleles from population 1.  Usage:

geno_lik2 d t

*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define SMAX 1500000

int main (int argc, char *argv[])
{
  int a, c1, c2, c0, b, c, s, *anc;
  double *pos, *lik2, *lik1, *lik0, p0, p1, p2, d, delta, t, posit;

  if (argc != 3) {
    printf("Usage: geno_lik2 d t\n");
    exit(0);
  }

  d = atof (argv[1]);
  t = atof (argv[2]);
  lik2 = (double *) malloc (SMAX * sizeof (double));
  lik1 = (double *) malloc (SMAX * sizeof (double));
  lik0 = (double *) malloc (SMAX * sizeof (double));
  pos = (double *) malloc (SMAX * sizeof (double));
  anc = (int *) malloc (SMAX * sizeof (int));
  for (a=0; a<SMAX; ++a)
    anc[a] = -1;

  s=0;
  while (scanf("%lf %lf %lf %lf %lf\n", &posit, &delta, &p2, &p1, &p0) != EOF) {
    if ((delta > (d - 1.E-10)) && p0>1.E-06 && p1>1.E-06 && p2>1.E-06) {
      lik2[s] = log (p2);
      lik1[s] = log (p1);
      lik0[s] = log (p0);
      pos[s] = posit;
      ++s;
    }
  }

  for (a=0; a<s; ++a) {
    p0 = p1 = p2 = 0.;
    for (b=0; pos[b]<(pos[a]+t*.5); ++b) 
      if (pos[b]>(pos[a]-t*.5)) {
	p0 += lik0[b];
	p1 += lik1[b];
	p2 += lik2[b];
      }
    if (p0>p1 && p0>p2)
      anc[a] = 0;
    else if (p1>p0 && p1>p2)
      anc[a] = 1;
    else if (p2>p0 && p2>p1)
      anc[a] = 2;
  }

  for (a=0; a<s; ++a) {
    c1 = c2 = c0 = 0;
    for (b=0; b<s; ++b)
      if ((pos[a]-pos[b]) < t*.5 && (pos[a]-pos[b])>(t*(-.5))) {
	if (anc[b] == 0)
	  ++c0;
	else if (anc[b] == 1)
	  ++c1;
	else if (anc[b] == 2)
	  ++c2;
      }
    if (c0>c1 && c0>c2)
      c = 0;
    else if (c1>c0 && c1>c2)
      c = 1;
    else if (c2>c0 && c2>c1)
      c = 2;
    else
      c = -1;

    printf("%f\t%d\n", pos[a], c);
  }
}
      
